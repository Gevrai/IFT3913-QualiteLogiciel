package uml.types;

public class StringType implements IType {

	@Override
	public String getTypeString() {
		return "String";
	}
}