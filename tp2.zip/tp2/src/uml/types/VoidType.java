package uml.types;

public class VoidType implements IType {

	@Override
	public String getTypeString() {
		return "Void";
	}
}