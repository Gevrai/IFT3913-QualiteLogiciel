package uml.types;

public class NumberType implements IType {

	@Override
	public String getTypeString() {
		return "Number";
	}
}