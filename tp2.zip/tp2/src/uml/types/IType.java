package uml.types;

public interface IType {
      
  public String getTypeString();

}