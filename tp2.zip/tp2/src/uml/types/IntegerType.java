package uml.types;

public class IntegerType implements IType {

	@Override
	public String getTypeString() {
		return "Integer";
	}
}