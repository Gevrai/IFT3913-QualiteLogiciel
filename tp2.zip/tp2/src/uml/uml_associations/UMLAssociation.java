package uml.uml_associations;

import uml.uml_classes.UMLClass;

public abstract class UMLAssociation {

}