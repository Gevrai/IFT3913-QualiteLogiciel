package uml.uml_classes;

import uml.types.IType;

public class Argument extends Variable {

	public Argument(String argName, IType argType) {
		super(argName, argType);
	}
}