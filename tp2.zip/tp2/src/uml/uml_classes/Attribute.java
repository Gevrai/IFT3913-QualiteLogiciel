package uml.uml_classes;

import uml.types.IType;

public class Attribute extends Variable {

	public Attribute(String name, IType type) {
		super(name, type);
	}

}